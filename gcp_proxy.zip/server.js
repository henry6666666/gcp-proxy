// server.js
const express = require('express');
const fetch = require('node-fetch');
const cors = require('cors');
const { URL } = require('url');

const app = express();
app.use(cors());
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.all('/proxy', async (req, res) => {
  try {
    const target = (req.query.target || req.body.target || '').toString();
    if (!target) return res.status(400).send('Missing target parameter');

    const u = new URL(target);
    if (!['http:', 'https:'].includes(u.protocol)) {
      return res.status(400).send('Invalid protocol');
    }

    const headers = { ...req.headers };
    delete headers.host;
    delete headers.connection;

    const fetchOpts = { method: req.method, headers, redirect: 'manual' };
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      fetchOpts.body = JSON.stringify(req.body);
    }

    const upstream = await fetch(target, fetchOpts);
    res.status(upstream.status);
    upstream.headers.forEach((value, name) => {
      if (['content-length','transfer-encoding'].includes(name.toLowerCase())) return;
      res.setHeader(name, value);
    });

    res.setHeader('Access-Control-Allow-Origin','*');
    const body = upstream.body;
    if (body) body.pipe(res); else res.end();
  } catch (err) {
    res.status(500).send('Proxy error: ' + err.message);
  }
});

app.get('/', (req, res) => {
  res.send("Proxy server running.");
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Proxy running on ${PORT}`));
